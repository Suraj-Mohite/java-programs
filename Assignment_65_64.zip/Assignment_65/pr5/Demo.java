import java.lang.*;
import java.util.*;

class Pattern
{
	public void DisplayPattern(int iRow,int iCol)
	{
		if(iRow!=iCol||iRow==0||iCol==0)
		{
			return;
		}
		
		for(int i=1;i<=iRow;i++)
		{
			for(int j=1;j<=iCol;j++)
			{
				if((i==1)||(j==1)||(i==iRow)||(j==iCol)||(i==j))
				{
					System.out.print(j+"\t");
				}
				else{
					System.out.print(" \t");
				}
			}
			System.out.println();
		}
	}
}

class Demo
{
	public static void main(String args[])
	{
		Scanner sobj=new Scanner(System.in);
		System.out.println("Enter the number of rows");
		int iRow=sobj.nextInt();
		
		System.out.println("Enter the numbner of columns");
		int iCol=sobj.nextInt();
		
		Pattern pobj=new Pattern();
		
		pobj.DisplayPattern(iRow,iCol);
	}
}