import java.lang.*;
import java.util.*;

class Pattern
{
	public void DisplayPattern(String str)
	{
		char arr[]=str.toCharArray();
		for(int i=0;i<(2*(arr.length))-1;i++)
		{
			for(int j=0;j<(arr.length);j++)
			{
				if(i<arr.length&&j<(arr.length-i))
				{
					System.out.print(arr[j]+"\t");
				}
				else if(i>=arr.length&&j<=(i-(arr.length-1)))
				{
					System.out.print(arr[j]+"\t");
				}
				else
				{
					System.out.print("*\t");
				}					
			}
			System.out.println();
		}
	}
}

class Demo
{
	public static void main(String[]args)
	{
		Scanner sobj=new Scanner(System.in);
		System.out.println("Enter the string");
		String str=sobj.nextLine();
		
		Pattern pobj=new Pattern();
		
		pobj.DisplayPattern(str);
		
	}
}