import java.lang.*;
import java.util.*;

class Pattern
{
	public void DisplayPattern(String str)
	{
		char arr[]=str.toCharArray();
		for(int i=0;i<(arr.length);i++)
		{
			for(int j=0;j<(arr.length);j++)
			{
				if(j<(arr.length-i))
				{
					System.out.print(arr[j]+"\t");
				}
				else
				{
					System.out.print("#\t");
				}					
			}
			System.out.println();
		}
	}
}

class Demo
{
	public static void main(String[]args)
	{
		Scanner sobj=new Scanner(System.in);
		System.out.println("Enter the string");
		String str=sobj.nextLine();
		
		Pattern pobj=new Pattern();
		
		pobj.DisplayPattern(str);
		
	}
}