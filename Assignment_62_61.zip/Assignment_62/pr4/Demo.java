import java.lang.*;
import java.util.*;

class Matrix
{
	public boolean SwapCol(int arr[][],int iRow,int iCol)
	{
		int iCnt=0,iCnt1=0;
		
		for(int i=0;i<(arr.length);i++)
		{
			for(int j=0;j<(arr[i].length);j++)
			{
				if(arr[i][j]==0)
				{
					iCnt++;
				}
				else
				{
					iCnt1++;
				}					
			}
		}
		if(iCnt>iCnt1)
		{
			return true;
		}
		else{
			return false;
		}
	}
}

class Demo
{
	public static void main(String[]args)
	{
		Scanner sobj=new Scanner(System.in);
		System.out.println("Enter the number of rows");
		int iRow=sobj.nextInt();
		
		System.out.println("Enter the number of columns");
		int iCol=sobj.nextInt();
		
		int arr[][]=new int[iRow][iCol];
		Matrix mobj=new Matrix();
		
		System.out.println("Enter the elements of matrix");
		
		for(int i=0;i<arr.length;i++)
		{
			for(int j=0;j<arr[i].length;j++)
			{
				arr[i][j]=sobj.nextInt();
			}
		}
		
		for(int i=0;i<arr.length;i++)
		{
			for(int j=0;j<arr[i].length;j++)
			{
				System.out.print(arr[i][j]+"\t");
			}
			System.out.println("\n");
		}
		
		boolean bRet=mobj.SwapCol(arr,iRow,iCol);
		if(bRet==true)
		{
			System.out.println("it is Sparse matrix");
		}
		else{
			System.out.println("not sparse matrix");
		}
		
	}
}