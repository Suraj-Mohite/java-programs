import java.lang.*;
import java.util.*;

class Matrix
{
	public void SwapRows(int arr[][],int iRow,int iCol)
	{
		if(iRow%2!=0)
		{
			return;
		}
		
		int temp=0;
		
		for(int i=0;i<arr.length;i++)
		{
			for(int j=0;j<arr[i].length;j++)
			{
				if(i%2==0)
				{
					temp=arr[i][j];
					arr[i][j]=arr[i+1][j];
					arr[i+1][j]=temp;
				}
				
			}
		
		}
		for(int i=0;i<arr.length;i++)
		{
			for(int j=0;j<arr[i].length;j++)
			{
				System.out.print(arr[i][j]+"\t");
			}
			System.out.println();
		}
	}
}

class Demo
{
	public static void main(String[]args)
	{
		Scanner sobj=new Scanner(System.in);
		System.out.println("Enter the number of rows");
		int iRow=sobj.nextInt();
		
		System.out.println("Enter the number of columns");
		int iCol=sobj.nextInt();
		
		int arr[][]=new int[iRow][iCol];
		Matrix mobj=new Matrix();
		
		System.out.println("Enter the elements of matrix");
		
		for(int i=0;i<arr.length;i++)
		{
			for(int j=0;j<arr[i].length;j++)
			{
				arr[i][j]=sobj.nextInt();
			}
		}
		
		mobj.SwapRows(arr,iRow,iCol);
		
	}
}