import java.lang.*;
import java.util.*;

class Matrix
{
	public void AddColumn(int arr[][],int iRow,int iCol)
	{
		//logic for invalid input
		
		int temp[]=new int[iCol];
		
		for(int i=0;i<arr.length;i++)
		{
			for(int j=0;j<arr[i].length;j++)
			{
				temp[j]=temp[j]+arr[i][j];
			}
		}
		for(int i=0;i<temp.length;i++)
		{
			System.out.print(temp[i]+"\t");
		}
	}
}

class Demo
{
	public static void main(String[]args)
	{
		Scanner sobj=new Scanner(System.in);
		System.out.println("Enter the number of rows");
		int iRow=sobj.nextInt();
		
		System.out.println("Enter the number of columns");
		int iCol=sobj.nextInt();
		
		int arr[][]=new int[iRow][iCol];
		Matrix mobj=new Matrix();
		
		System.out.println("Enter the elements of matrix");
		
		for(int i=0;i<arr.length;i++)
		{
			for(int j=0;j<arr[i].length;j++)
			{
				arr[i][j]=sobj.nextInt();
			}
		}
		
		mobj.AddColumn(arr,iRow,iCol);
		
	}
}