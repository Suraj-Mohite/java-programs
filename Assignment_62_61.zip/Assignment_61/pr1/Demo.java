import java.lang.*;
import java.util.*;

class Matrix
{
	public int AddDiagonal(int arr[][],int iRow,int iCol)
	{
		int iSum=0;
		if(iRow!=iCol||iRow==0||iCol==0)
		{
			System.out.println("ERROR:Invalid Input");
		}
		else
		{
			for(int i=0;i<arr.length;i++)
			{
				for(int j=0;j<arr[i].length;j++)
				{
					if(i==j)
					{
						iSum=iSum+arr[i][j];
					}
				}
			}
			
		}
		return iSum;
	}
}

class Demo
{
	public static void main(String arg[])
	{
		int iRow=0,iCol=0,iRet=0;
		
		Scanner sobj=new Scanner(System.in);
		System.out.println("Enter the number of rows");
		iRow=sobj.nextInt();
		System.out.println("Enter the number of columns");
		iCol=sobj.nextInt();
		
		int arr[][]=new int[iRow][iCol];
		System.out.println("Enter the elements");
		
		for(int i=0;i<arr.length;i++)
		{
			for(int j=0;j<arr[i].length;j++)
			{
				arr[i][j]=sobj.nextInt();
			}
		}
		
		for(int i=0;i<arr.length;i++)
		{
			for(int j=0;j<arr[i].length;j++)
			{
				System.out.print(arr[i][j]+"\t");
			}
			System.out.println();
		}
		Matrix mobj=new Matrix();
		iRet=mobj.AddDiagonal(arr,iRow,iCol);
		
		System.out.println("Addition of the diadonals is :"+iRet);
		
	}
}