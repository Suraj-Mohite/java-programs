import java.lang.*;
import java.util.*;

class Matrix
{
	public int Frequency(int arr[][],int iRow,int iCol,int iNo)
	{
		int iCnt=0;
		if((iRow!=iCol)||iRow==0||iCol==0)
		{
			return -1;
		}
		
		for(int i=0;i<arr.length;i++)
		{
			for(int j=0;j<arr[i].length;j++)
			{
				if(arr[i][j]==iNo)
				{
					iCnt++;
				}
			}
		}
		return iCnt;
	}
}

class Demo
{
	public static void main(String[]args)
	{
		Scanner sobj=new Scanner(System.in);
		System.out.println("Enter the number of rows");
		int iRow=sobj.nextInt();
		System.out.println("Enter the number of columns");
		int iCol=sobj.nextInt();
		
		int arr[][]=new int[iRow][iCol];
		
		System.out.println("Enter the elements");
		for(int i=0;i<arr.length;i++)
		{
			for(int j=0;j<arr[i].length;j++)
			{
				arr[i][j]=sobj.nextInt();
			}
		}
		System.out.println("Enter the number whose frequency want to find");
		int iNo=sobj.nextInt();
		
		Matrix mobj=new Matrix();
		
		int iRet=mobj.Frequency(arr,iRow,iCol,iNo);
		if(iRet==0)
		{
			System.out.println("There is no such number in matrix");
		}
		else if(iRet==-1)
		{
			System.out.println("ERROR:Invallid Matrix");
		}
		else
		{
			System.out.println("Frequency of "+iNo+" is "+iRet);
		}
	}
}