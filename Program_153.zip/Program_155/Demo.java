//count number of words

import java.lang.*;
import java.util.*;


class Demo
{
	public static void main(String[]args)throws Exception
	{
		Scanner sobj=new Scanner(System.in);
		
		System.out.println("First string: ");
		String str=sobj.nextLine();
		
		MyString obj=new MyString();
		obj.MaxWord(str);
		
		
	}
}

class MyString
{
	void MaxWord(String str)throws Exception
	{
		int imax=0;
		String arr[]=str.split(" ");
		String Temp=null;
		for(String name:arr)
		{
			if(name.length()>imax)
			{
				imax=name.length();
				Temp=name;
			}
		}
		System.out.println("largest word "+Temp+" with length "+imax);
	}
}
