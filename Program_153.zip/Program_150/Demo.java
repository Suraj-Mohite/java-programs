import java.lang.*;
import java.util.*;


class Demo
{
	public static void main(String[]args)
	{
		Scanner sobj=new Scanner(System.in);
		
		System.out.println("First string: ");
		String str1=sobj.nextLine();
		
		System.out.println("second string: ");
		String str2=sobj.nextLine();
		
		MyString obj=new MyString();
		boolean ret=obj.CheckAnagram(str1,str2);
		if(ret==true)
		{
			System.out.println("string is anagram");
		}
		else
		{
			System.out.println("not anagram");
		}
	}
}

class MyString
{
	boolean CheckAnagram(String str1,String str2)
	{
		if(str1.length()!=str2.length())
		{
			return false;
		}
		char arr[]=str1.toCharArray();
		char brr[]=str2.toCharArray();
		
		Arrays.sort(arr);
		Arrays.sort(brr);
		
		String s1=new String(arr);
		String s2=new String(brr);
		
		boolean bret=s1.equals(s2);
		return bret;
	}
}