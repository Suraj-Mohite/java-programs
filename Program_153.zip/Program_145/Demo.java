
import java.lang.*;
import java.util.*;

class selection
{
	public void sort(int arr[])
	{
		for(int pass=0;pass<arr.length-1;pass++)
		{
			int min=pass;
			for(int j=pass+1;j<arr.length;j++)
			{
				if(arr[min]>arr[j])
				{
					min=j;
				}
			}
			if(arr[pass]!=arr[min])
			{
				int Temp=arr[pass];
				arr[pass]=arr[min];
				arr[min]=Temp;
			}
			
		}
	}
}
class Demo
{
	public static void main(String []args)
	{
		Scanner sobj=new Scanner(System.in);
		System.out.println("Enter the size of attay\n");
		
		int size=sobj.nextInt();
		
		int arr[]=new int [size];
		System.out.println("Enter the values");
		
		for(int i=0;i<arr.length;i++)
		{
			arr[i]=sobj.nextInt();
		}
		
		selection bobj=new selection();
		bobj.sort(arr);
		System.out.println("After sorting");
		for(int i=0;i<arr.length;i++)
		{
			System.out.print(arr[i]+"\t");
		}
		System.out.println();
	}
}