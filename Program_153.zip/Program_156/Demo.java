//reverse each word
import java.lang.*;
import java.util.*;


class Demo
{
	public static void main(String[]args)throws Exception
	{
		Scanner sobj=new Scanner(System.in);
		
		System.out.println("First string: ");
		String str=sobj.nextLine();
		
		MyString obj=new MyString();
		obj.RevWord(str);
		
		
	}
}

class MyString
{
	void RevWord(String str)throws Exception
	{
		String arr[]=str.split(" ");
		StringBuilder nstr=new StringBuilder();
		for(String name:arr)
		{
			StringBuilder sb=new StringBuilder(name);
				
			String Temp=sb.reverse().toString();
			nstr.append(Temp+" ");
		}
		System.out.println("updated string is "+nstr);
	}
}
