
//C:\Program Files\Apache Software Foundation\Tomcat 9.0\webapps\MyApp1\WEB-INF\classes
// yaa path madhe classes folder madhe fakt .class file thewayachi aste. aata fakt learning sathi mi .java file pn ithech thevat aahe.
//MyApp1\WEB-INF\classes  <-> mi tayaar kele aahe 
import javax.servlet.*;
import java.io.*;

public class MyFirstServlet extends GenericServlet
{
	public void service(ServletRequest req,ServletResponse resp)throws IOException,ServletException
	{
		PrintWriter out=resp.getWriter();
		out.print("Hello Suraj, Welcome to Servlet");
	}
}