import java.lang.*;
import java.util.*;


class Demo
{
	public static void main(String[]args)throws Exception
	{
		Scanner sobj=new Scanner(System.in);
		
		System.out.println("First string: ");
		String str=sobj.nextLine();
		
		
		MyString obj=new MyString();
		obj.CheckFrequency(str);
	}
}

class MyString
{
	void CheckFrequency(String str)throws Exception
	{
		char arr[]=str.toCharArray();
		
		HashMap <Character,Integer> hobj=new HashMap<Character,Integer>();
		
		for(char c:arr)
		{
			if(hobj.containsKey(c))
			{
				hobj.put(c,hobj.get(c)+1);
			}
			else
			{
				hobj.put(c,1);
			}
		}
		
		System.out.println("Frequency of Each Char is: ");
		System.out.println(hobj);
		
	}
}