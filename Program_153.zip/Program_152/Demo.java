//chk string is rotation or not

import java.lang.*;
import java.util.*;


class Demo
{
	public static void main(String[]args)throws Exception
	{
		Scanner sobj=new Scanner(System.in);
		
		System.out.println("First string: ");
		String str1=sobj.nextLine();
		
		System.out.println("second string: ");
		String str2=sobj.nextLine();
		
		MyString obj=new MyString();
		boolean ret=obj.CheckRotation(str1,str2);
		if(ret==true)
		{
			System.out.println("string is rotation");
		}
		else
		{
			System.out.println("not rotation");
		}
	}
}

class MyString
{
	boolean CheckRotation(String str1,String str2)throws Exception
	{
		if(str1.length()!=str2.length())
		{
			return false;
		}
		String str3=str1+str1;
		if(str3.contains(str2))
		{
			return true;
		}
		else{
			return false;
		}
		
	}
}