
import java.lang.*;
import java.util.*;

class Insersion
{
	public void sort(int arr[])
	{
		for(int pass=1;pass<arr.length;pass++)
		{
			int key=arr[pass];
			int j=pass-1;
			
			while((j>=0)&&(arr[j]>key))
			{
				arr[j+1]=arr[j];
				j--;
			}
			arr[j+1]=key;
		}
	}
}
class Demo
{
	public static void main(String []args)
	{
		Scanner sobj=new Scanner(System.in);
		System.out.println("Enter the size of attay\n");
		
		int size=sobj.nextInt();
		
		int arr[]=new int [size];
		System.out.println("Enter the values");
		
		for(int i=0;i<arr.length;i++)
		{
			arr[i]=sobj.nextInt();
		}
		
		Insersion bobj=new Insersion();
		bobj.sort(arr);
		System.out.println("After sorting");
		for(int i=0;i<arr.length;i++)
		{
			System.out.print(arr[i]+"\t");
		}
		System.out.println();
	}
}