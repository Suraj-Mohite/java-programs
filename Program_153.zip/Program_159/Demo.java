//reverse each word
import java.lang.*;
import java.util.*;


class Demo
{
	public static void main(String[]args)throws Exception
	{
		Scanner sobj=new Scanner(System.in);
		
		System.out.println("First string: ");
		String str=sobj.nextLine();
		
		MyString obj=new MyString();
		obj.RevWord(str);
		
		
	}
}

class MyString
{
	void RevWord(String str)throws Exception
	{
		String arr[]=str.split(" ");
		HashMap<String,Integer>WordCount=new HashMap<String,Integer>();
		for(String s:arr)
		{
			if(WordCount.containsKey(s.toLowerCase()))
			{
				WordCount.put(s.toLowerCase(),WordCount.get(s.toLowerCase())+1);
			}
			else
			{
				WordCount.put(s.toLowerCase(),1);
			}
		}
		System.out.println("result is ");
		System.out.println(WordCount);
		
		Set<String>words=WordCount.keySet();
		
		for(String word:words)
		{
			if(WordCount.get(word)>1)
			{
				System.out.println(word+"occurs"+WordCount.get(word)+" times");
			}
		}
	}
}
