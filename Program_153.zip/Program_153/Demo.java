//count number of words

import java.lang.*;
import java.util.*;


class Demo
{
	public static void main(String[]args)throws Exception
	{
		Scanner sobj=new Scanner(System.in);
		
		System.out.println("First string: ");
		String str=sobj.nextLine();
		
		MyString obj=new MyString();
		int ret=obj.CountWord(str);
		System.out.println(ret);
		
		
	}
}

class MyString
{
	int CountWord(String str)throws Exception
	{
		return((str.split(" ")).length);
	}
}