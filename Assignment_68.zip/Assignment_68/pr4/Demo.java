import java.lang.*;
import java.util.*;

class Arrayx
{
	public int cap(char arr[])
	{
		int iCnt=0;
		for(int i=0;i<arr.length;i++)
		{
			if(arr[i]>='A'&&arr[i]<='Z')
			{
				iCnt++;
			}
		}
		return iCnt;
	}
}

class Demo
{
	public static void main(String args[])
	{
		Scanner sobj=new Scanner(System.in);
		System.out.println("Enter the number of elements");
		int iNo=sobj.nextInt();
		
		char arr[]=new char[iNo];
		System.out.println("Enter elements");
		
		for(int i=0;i<arr.length;i++)
		{
			arr[i]=sobj.next().charAt(0);
		}
		
		Arrayx pobj=new Arrayx();
		
		int iret=pobj.cap(arr);
		System.out.println(iret);
	}
}