import java.lang.*;
import java.util.*;

class Arrayx
{
	public void Reverse(int arr[])
	{
		int iRev=0;
		for(int i=0;i<arr.length;i++)
		{
			iRev=0;
			while(arr[i]!=0)
			{
				iRev=(iRev*10)+(arr[i]%10);
				arr[i]=arr[i]/10;
			}
			System.out.print(iRev+"\t");
		}
	}
}

class Demo
{
	public static void main(String args[])
	{
		Scanner sobj=new Scanner(System.in);
		System.out.println("Enter the number of elements");
		int iNo=sobj.nextInt();
		
		int arr[]=new int[iNo];
		System.out.println("Enter elements");
		
		for(int i=0;i<arr.length;i++)
		{
			arr[i]=sobj.nextInt();
		}
		
		Arrayx pobj=new Arrayx();
		
		pobj.Reverse(arr);
	}
}