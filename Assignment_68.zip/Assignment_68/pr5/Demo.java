import java.lang.*;
import java.util.*;

class Arrayx
{
	public void per(float arr[])
	{
		for(int i=0;i<arr.length;i++)
		{
			float no=arr[i];
			if((no>=0)&&(no<35))
			{
				System.out.println("FAIL");
			}
			else if((no>=35)&&(no<50))
			{
				System.out.println("pass");
			}
			else if((no>=50)&&(no<60))
			{
				System.out.println("second class");
			}
			else if((no>=60)&&(no<70))
			{
				System.out.println("first class");
			}
			else 
			{
				System.out.println("first class with distinction");
			}
			
		}
	}
}

class Demo
{
	public static void main(String args[])
	{
		Scanner sobj=new Scanner(System.in);
		System.out.println("Enter the number of elements");
		int iNo=sobj.nextInt();
		
		float arr[]=new float[iNo];
		System.out.println("Enter elements");
		
		for(int i=0;i<arr.length;i++)
		{
			arr[i]=sobj.nextFloat();
		}
		
		Arrayx pobj=new Arrayx();
		
		pobj.per(arr);
	}
}